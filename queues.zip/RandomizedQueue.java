/*----------------------------------------------------------------
 *  Author:        Debalina Ghosh
 *  Written:       2/20/2013
 *  Last updated:  2/20/2013
 *
 * 
 *  Implements a randomized queue where the item removed is chosen
 *  uniformly at random from items in the data structure. We implement
 *  the randomized queue using a resizing array. The order of two or more 
 *  iterators to the same randomized queue should be mutually independent; 
 *  each iterator must maintain its own random order.
 *  
 *
 *----------------------------------------------------------------*/

import java.util.Iterator;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private int N;
    private Item[] q;
    
  // construct an empty randomized queue
  public RandomizedQueue()     {
      q = (Item[]) new Object[1];
      N = 0;
  }
  
   // is the queue empty?
  public boolean isEmpty() {
      return (N == 0);
  }
  
   // return the number of items on the queue
   public int size()  {
       return N;
   }
     
  // add the item 
   public void enqueue(Item item)     {
       if (item == null) throw new java.lang.NullPointerException();
       if (N == q.length) resize(2 * q.length);
       q[N++] = item;
       
   }
   // delete and return a random item 
   public Item dequeue()    {
       if (N == 0)  throw new java.util.NoSuchElementException();
      
        int randomIndex = StdRandom.uniform(N);
        Item item = q[randomIndex];
        
        //exchange chosen item with last item in array
        if (randomIndex != (N-1)) {
          q[randomIndex] = q[N-1];
        }
        
        q[N-1] = null;
        
        //decrease size of queue
        if (item!= null) N--;
        if (N > 0 && N == q.length/4) resize(q.length/2);
        return item;
   }
   
 
  
     
   private void resize(int capacity) {
       Item[] copy = (Item[]) new Object[capacity];
       int j = 0;
       for (int i = 0; i < N; i++) {
         if (q[i] != null) {
             copy[j] = q[i];
             j++;
         }
       }
       q = copy;
   }
   
   // return (but do not delete) a random item
   public Item sample()   {
       if (N == 0) throw new java.util.NoSuchElementException();
       int randomIndex = StdRandom.uniform(N);
       return q[randomIndex];
   }
   
   // return an independent iterator over items in random order

   
   public Iterator<Item> iterator()  { return new RandomizedQIterator(); }

   
    private class RandomizedQIterator implements Iterator<Item> {
       private int[] iterList = new int[N];
 
       private int iterIndex = 0;
       
       public RandomizedQIterator() {
         for (int i = 0; i < N; i++) {
             iterList[i] = i;
         }
         
         //shuffle the array indexes so that next returns items in random
         // order.
         StdRandom.shuffle(iterList);
         
       }
      
        
      public boolean hasNext() {
          return (iterIndex < N);
       }
        
       public void remove() {
          throw new java.lang.UnsupportedOperationException();
       }
        
       public Item next() {
          if (iterIndex == N) throw new java.util.NoSuchElementException();
          //iterList[iterIndex] gives the indices of the original array
          // in random order.
          Item item = q[iterList[iterIndex]];
          iterIndex++;
          return item;
          
        }
    }
}
    
    