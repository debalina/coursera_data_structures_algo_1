/*------------------------------------------------------------------------------------
 *            AUTHOR:   Debalina Ghosh
 *            WRITTEN:   2/20/13
 *            UPDATED:   2/20/12
 * This is a client program Subset.java that takes a command-line 
 * integer k,reads in a sequence of N strings from standard input
 * using StdIn.readString(),and prints out exactly k of them, 
 * uniformly at random. Each item from the sequence can be 
 * printed out at most once. We assume that k is greater than or 
 * equal to 0 and no greater than the number of string on standard 
 * input. We use the randomized Queue class.
*------------------------------------------------------------------------------------*/

public class Subset {
  public static void main(String[] args) {
    
     // read in strings from standard input
     String[] inputString = StdIn.readStrings();
    
    
     // randomized Queue constructor
     RandomizedQueue<String> randomQ = new RandomizedQueue<String>();
    
     for (int i = 0; i < inputString.length; i++) {
        randomQ.enqueue(inputString[i]);
      }
    
     //read K
    
      int K = Integer.parseInt(args[0]);
     // print out K strings 
     int i = 0;
     for (String x : randomQ) {
         if (i == K) break;
         StdOut.println(x);
         i++;
      }
  }
}