/*----------------------------------------------------------------
 *  Author:        Debalina Ghosh
 *  Written:       2/20/2013
 *  Last updated:  2/20/2013
 *
 * 
 *  Implements a double-ended queue or deque that supports insering 
 *  and removing items from either the front or the back of the data
 *  structure.
 *  
 *
 *----------------------------------------------------------------*/


import java.util.Iterator;



public class Deque<Item> implements Iterable<Item> {
    private int N;        // number of elements on list
    private Node head;     // sentinel before first item
    private Node tail;    // sentinel after last item

    public Deque() {
        head  = new Node();
        tail = new Node();
        head.next = tail;
        tail.prev = head;
        N = 0;
    }

    // linked list node helper data type
    private class Node {
        private Item item;
        private Node next;
        private Node prev;
    }

    public boolean isEmpty()    { return N == 0; }
    public int size()           { return N;      }

    // add the last item to the list
    public void addLast(Item item) {
        Node last = tail.prev;
        Node x = new Node();
        if (item == null) throw new java.lang.NullPointerException();
        x.item = item;
        x.next = tail;
        x.prev = last;
        tail.prev = x;
        last.next = x;
        N++;
    }

    // add the first item to the list
    public void addFirst(Item item) {
        Node first = head.next;
        Node x = new Node();
        if (item == null) throw new java.lang.NullPointerException();
        x.item = item;
        x.next = first;
        x.prev = head;
        first.prev = x;
        head.next = x;
        N++;
    }
    
     // delete and return the item at the front
    public Item removeFirst()   {
      Node first = head.next;
      if (first == tail) throw new java.util.NoSuchElementException();
      Node newFirst = first.next;
      head.next = newFirst;
      newFirst.prev = head;
      N--;
      return first.item;
    }
      
    // delete and return the item at the end
    public Item removeLast() {
      Node last = tail.prev;
      if (last == head) throw new java.util.NoSuchElementException();
      Node newLast = last.prev;
      newLast.next = tail;
      tail.prev = newLast;
      N--;
      return last.item;
    }
    
    public Iterator<Item> iterator()  { return new DequeIterator(); }

   
    private class DequeIterator implements Iterator<Item> {
        private Node current = head.next;  //first item in Deque
        
        public boolean hasNext() {
          return current != tail;
        }
        
        public void remove() {
          throw new java.lang.UnsupportedOperationException();
        }
        
        public Item next() {
          if (current == tail) throw new java.util.NoSuchElementException();
          Item item = current.item;
          current = current.next;
          return item;
        }
    }
}

   