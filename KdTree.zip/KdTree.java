/*************************************************************************
 *  
 *  Dependencies: Point2D.java In.java StdDraw.java
 *
 *  This implements a data type that represents points in a unit square.
 *  It uses a 2d-tree where the nodes store the points, using the x- and
 *  y-coordinates of the points as keys in strictly alternating sequence.
 * 
 *  Each node corresponds to an axis-aligned rectangle in the unit square, 
 *  which encloses all of the points in its subtree. The root corresponds 
 *  to the unit square; the left and right children of the root corresponds
 *  to the two rectangles split by the x-coordinate of the point at the 
 *  root; and so forth.
 *  
 *
 *************************************************************************/


public class KdTree {
    private Node root;
    private int size = 0;
   
    
    private static class Node {
        private Point2D p;
        private RectHV rect;
        private Node left;
        private Node right;
        
        public  Node(Point2D point, RectHV rect, Node left, Node right)
        {
            this.p = point;
            this.rect = rect;
            this.left = left;
            this.right = right;
        }
    }
    public KdTree()  {
      // construct an empty set of points
      root = null;
    }
    public boolean isEmpty() {
      // is the set empty?
      return (root == null);
    }
    public int size() {
      // number of points in the set
      return size;
    }
    public void insert(Point2D point) {
      // add the point p to the set (if it is not already in the set)
       root = insert(root, point, 0, 0, 1, 1, true);
    }
    
    private Node insert(Node current, Point2D point, double xmin, double ymin,
                        double xmax, double ymax, boolean xAxis) {
        //helper function to insert a node into a kdtree
       if (current == null) {
       // node needs to be inserted here
           size++;
           RectHV r = new RectHV(xmin, ymin, xmax, ymax);
           return new Node(point, r, null, null);
      }
       //found point. no need to insert duplicate.
       if (current.p.equals(point)) return current;
       
      
       //if xAxis is true, compare x coordinates
       //otherwise, compare y coordinates
       
       if (xAxis) {
           if (point.x() < current.p.x()) {
             //go to left subtree
               xmax = current.p.x();
               current.left = insert(current.left, point,
                                     xmin, ymin, xmax, ymax, !xAxis);
             
            } else {
             //go to right subtree
                xmin = current.p.x();
                current.right = insert(current.right, point, 
                                       xmin, ymin, xmax, ymax, !xAxis);
            }
       } else {
           if (point.y() < current.p.y()) {
             //go to left subtree
               ymax = current.p.y();
               current.left = insert(current.left, point,
                                     xmin, ymin, xmax, ymax, !xAxis);
             
           } else {
             //go to right subtree
               ymin = current.p.y();
               current.right = insert(current.right, point, 
                                      xmin, ymin, xmax, ymax, !xAxis);
           }
       }
      
       return current;
    }
    
    public boolean contains(Point2D point)   {
        // does the set contain the point p?
        return contains(root, point, true);
    }
    
     private boolean contains(Node current, Point2D point, boolean xAxis) {
        //helper function to find a point in a kdtree
       
       //point not found
       if (current == null) return false;
       
       //found point
       if (current.p.equals(point)) return true;
       
       //if xAxis is true, compare x coordinates
       //otherwise, compare y coordinates
       
       if (xAxis) {
           if (point.x() < current.p.x()) {
             //go to left subtree
               return contains(current.left, point, !xAxis);
          } else {
             //go to right subtree
             return contains(current.right, point, !xAxis);
         }
       } else {
         if (point.y() < current.p.y()) {
             //go to left subtree
             return contains(current.left, point, !xAxis);
         } else {
             //go to right subtree
             return contains(current.right, point, !xAxis);
         }
       }
    }

   
    public void draw() {
        // draw all of the points to standard draw
        RectHV unitRect = new RectHV(0, 0, 1, 1);
        unitRect.draw();
        draw(root, false);
    }
    
    private void draw(Node current, boolean xAxis) {
        //private helper function for draw
      double pt1X, pt1Y, pt2X, pt2Y;
      
      if (current == null) return;
      StdDraw.setPenColor(StdDraw.BLACK);
      StdDraw.setPenRadius(.01);
      current.p.draw();
      if (!xAxis) {
          pt1X = current.p.x();
          pt1Y = current.rect.ymin();
          pt2X = current.p.x();
          pt2Y = current.rect.ymax();
          StdDraw.setPenColor(StdDraw.RED);
         
      } else {
         pt1X = current.rect.xmin();
         pt1Y = current.p.y();
         pt2X = current.rect.xmax();
         pt2Y = current.p.y();
         StdDraw.setPenColor(StdDraw.BLUE);
         
      }
      StdDraw.setPenRadius();
      StdDraw.line(pt1X, pt1Y, pt2X, pt2Y);
      draw(current.left, !xAxis);
      draw(current.right, !xAxis);
    }
   
    public Iterable<Point2D> range(RectHV rect)   {
        // all points in the set that are inside the rectangle
       Queue<Point2D> queue = new Queue<Point2D>();
       
       range(root, queue, rect);
       return queue;
    }
    
    private void range(Node current, Queue<Point2D> queue, RectHV rect) {
        if (current == null) return;
        
        if (current.rect.intersects(rect)) {
          if (rect.contains(current.p)) {
              queue.enqueue(current.p);
          }
          range(current.left, queue, rect);
          range(current.right, queue, rect);
        }
        return;
    }
    public Point2D nearest(Point2D p) {
       Point2D champion = new Point2D(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
       Point2D oldchampion = new Point2D(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
      // a nearest neighbor in the set to p; null if set is empty
       
       champion =  nearest(root, champion, p);
       
       if (champion.equals(oldchampion))
           return null;
       else
           return champion;
 
    }
    
    private Point2D nearest(Node current, Point2D champion, Point2D p) {
        
        if (current == null) return champion;
        
        double distance = Double.POSITIVE_INFINITY;
        
        if (champion != null)
            distance = champion.distanceTo(p);
        
        if ( (current.rect !=null) && (current.rect.distanceTo(p) > distance))
            return champion;
        
        if (current.p.distanceTo(p) < distance) {
            champion = current.p;
        }
        
        if ((current.left != null) && (current.right != null)) {
        //both left and right subtrees exist. find out order of 
        // traversal based on which subtree is closer to the query point
            if (current.left.rect.distanceTo(p) < current.right.rect.distanceTo(p)) {
                champion = nearest(current.left, champion, p);
                champion = nearest(current.right, champion, p);
            } else {
                champion = nearest(current.right, champion, p);
                champion = nearest(current.left, champion, p);
            }
        } else if (current.left != null) {
            champion = nearest(current.left, champion, p);
        } else {
            champion = nearest(current.right, champion, p);
        }
        
        return champion;
    }
}
