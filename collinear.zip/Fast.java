/*************************************************************************
 * Name: Debalina Ghosh
 * Email: debalina_ghosh@yahoo.com
 *
 * Compilation:  javac Fast.java
 * Execution:
 * Dependencies: StdDraw.java Point.java
 *
 * Description: This program uses sorting to determine line segments. It
 * thinks of a particular point p as the origin, and then it determines 
 * the slope p makes with every other point q. The points are then 
 * sorted according to the slopes they make with p. The program then 
 * checks for adjacent points in the sorted array making the same slope
 * with p. 
 *
 *************************************************************************/
import java.util.Arrays;
public class Fast {
  
  // Method to print the line segments and draw them. 
  private static void printAndDrawLines(Point[] p, int index, int count, Point refPoint){
    //compare refPoint with the starting point in array
    // to see whether line segment has been already printed out
    if (refPoint.compareTo(p[index - count + 1]) < 0) {
        StdOut.print(refPoint + "->");
        for (int i = index - count + 1; i < index ; i++)
            StdOut.print(p[i].toString() + "->");
        StdOut.println(p[index].toString());
        refPoint.drawTo(p[index]);
    }
   }
  

  public static void main(String[] args) {
     // rescale coordinates and turn on animation mode
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        StdDraw.show(0);

        // read in the input
        String filename = args[0];
        In in = new In(filename);
        int N = in.readInt();
        //read in points from input file and draw
        //those points.
        Point[] points = new Point[N];
        for (int i = 0; i < N; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
            points[i].draw();
        }
        StdDraw.show(0);
 
        // Sort the arrays in natural order.
        Arrays.sort(points);
        double savedSlope = -1 ;
        
        for (int origIndex = 0; origIndex < N; origIndex++)
        {
            // this is the origin.
            Point refPoint = points[origIndex];
           
            //make a copy of the original array that can
            // be sorted according to SLOPE_ORDER.
            Point[] copy = new Point[N];
           
           for (int i = 0; i < N; i++) {
             copy[i] = points[i];
           }
           
           
           Arrays.sort(copy, refPoint.SLOPE_ORDER);
           
           //Initialize count and index. We only consider
           // the part of the array whose indices are greater than
           // the reference point so that line segments are not repeated.
           int count = 1;
           int index = 0;
           while (index < N) { 
               double slope = refPoint.slopeTo(copy[index]);
               if (slope == savedSlope)  {
                  // if slope is same as savedSlope, just increment count
                  // at startIndex
                    count++;
               } else {
                   if (count >= 3) {
                   // this is a line segment
                        printAndDrawLines(copy, index - 1, count, refPoint);
                     }
                     savedSlope = slope;
                     count = 1;
                 }
                // go to next point
                index++;
            }
            //Before going to next point, check count
       if (count >= 3) {
            printAndDrawLines(copy, N - 1, count, refPoint);
        }
      } // end of for loop
      // display to screen all at once
       StdDraw.show(0);        
  }
  
}
             
  