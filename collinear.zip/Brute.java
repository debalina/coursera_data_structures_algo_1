/*************************************************************************
 * Name: Debalina Ghosh
 * Email: debalina_ghosh@yahoo.com
 *
 * Compilation:  javac Brute.java
 * Execution:
 * Dependencies: StdDraw.java Point.java
 *
 * Description: This program examines 4 points at a time and checks
 * whether they all lie on the same line segment. If the slopes 
 * between p and q, between p and r, and between p and s are equal,
 * then the 4 points p, q, r and s are collinear.
 *
 *************************************************************************/
import java.util.Arrays;

public class Brute {
  public static void main(String[] args) {
      // rescale coordinates and turn on animation mode
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        StdDraw.show(0);

        // read in the input
        String filename = args[0];
        In in = new In(filename);
        int N = in.readInt();
        //read in points from input file and draw
        //those points.
        Point[] points = new Point[N];
        for (int i = 0; i < N; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
            points[i].draw();
        }
        StdDraw.show(0);
        //sort the points so that we draw only one 
        // line for the collinear points.
        Arrays.sort(points);
        
        //check if 4 points are on the same line segment
        // The for loops start from the next index so that
        // the same set of 4 points are not considered more
        // than once.
        for (int i = 0; i < N; i++)
            for (int j = i + 1; j < N; j++)
                for (int k = j + 1; k < N; k++)
                    for (int l = k + 1; l < N; l++) {
                        double slopeToj = points[i].slopeTo(points[j]);
                        double slopeTok = points[i].slopeTo(points[k]);
                        double slopeTol = points[i].slopeTo(points[l]);
                        if ((slopeToj == slopeTok) && (slopeToj == slopeTol)) {
                             StdOut.print(points[i] + "->");
                             StdOut.print(points[j] + "->");
                             StdOut.print(points[k] + "->");
                             StdOut.println(points[l]);
                             
                             //draw line segment for the first to the end
                             //point
                             points[i].drawTo(points[l]);
                        }
        }
                        
                    

        // display to screen all at once
        StdDraw.show(0);
    }
}