/*----------------------------------------------------------------
 *  Author:        Debalina Ghosh
 *  Written:       3/16/2013
 *  Last updated:  3/16/2013
 *
 * 
 *  Implements a board of tiles corresponding to the 8-puzzle
 *  problem where there is a N X N grid. All the tiles are filled
 *  up expect one blank tile. The goal is to get all the tiles in 
 *  their proper position with the blank being the last tile in the
 *  grid. The Hamming and Manhattan priority
 * functions are implemented, where the hamming function is simply
 *  the number of blocks in the wrong position. The Manhattan function
 *  is the sum of the Manhattan distances (sum of the vertical and 
 *  horizontal distance) from the blocks to their goal positions.
 *  A twin board is a board obtained by switching two nonblank adjacent
 *  tiles in any row of the board.
 *
 *----------------------------------------------------------------*/
public class Board {
  
    private int[][] tiles;
    private int dimension;
    
    public Board(int[][] blocks) {
      // construct a board from an N-by-N array of blocks
       // (where blocks[i][j] = block in row i, column j)
      dimension = blocks[0].length;
      tiles = new int[dimension][dimension];
      for (int i = 0; i < dimension; i++)
        for (int j = 0; j < dimension; j++)
           tiles[i][j] = blocks[i][j];
    }
        
                                          
    public int dimension()  {
      // board dimension N
      return dimension;
    }
    
    private int[] calcGoalPos(int number) {
      // given a number, compute its position in the goal board
      int[] pos = new int[2];
      
      if (number % dimension == 0) {
        pos[0] = number/dimension - 1;
        pos[1] = dimension - 1;
      } else {
        pos[0] = number/dimension;
        pos[1] = number % dimension - 1;
      }
      return pos;
    }
        
    private int calcHamming(int number, int row, int col) {
      int[] goalPos = new int[2];
      
      // do not calculate hamming for blank tile
      if (number == 0)
        return 0;
      
      goalPos = calcGoalPos(number);
      
      if ((goalPos[0] != row) || (goalPos[1] != col)) {
        return 1;
      }
      return 0;
    }
    
    private int calcManhattan(int number, int row, int col) {
      int[] goalPos = new int[2];
       // do not calculate hamming for blank tile
      if (number == 0)
        return 0;
      
      goalPos = calcGoalPos(number);
      int value = 0;
      value =  Math.abs(goalPos[0] - row) + Math.abs(goalPos[1] - col);
      return value;
    }
    public int hamming() {
      // number of blocks out of place
      int hamming = 0;
      
      for (int i = 0; i < dimension; i++)
        for (int j = 0; j < dimension; j++) {
            hamming += calcHamming(tiles[i][j], i, j);
      }
      return hamming;
    }
    public int manhattan() {
      // sum of Manhattan distances between blocks and goal
      int manhattan = 0;
      for (int i = 0; i < dimension; i++)
        for (int j = 0; j < dimension; j++) 
            manhattan += calcManhattan(tiles[i][j], i, j);
      
      return manhattan;
    }
    public boolean isGoal()  {
      // is this board the goal board?
      if (hamming() != 0)
        return false;
      return true;
    }
    public Board twin()  {
      // a board obtained by exchanging two adjacent blocks in the same row
      int[][] twinTiles;
      int blankRow = 0;
      
      twinTiles = new int[dimension][dimension];
      for (int i = 0; i < dimension; i++)
        for (int j = 0; j < dimension; j++) {
              twinTiles[i][j] = tiles[i][j];
              // mark the row that contains the blank tile
              if (tiles[i][j] == 0) 
                blankRow = i;
      }
      
      Board twin = new Board(twinTiles);
      
     int chosenRow = 0;
     while (chosenRow == blankRow) {
       chosenRow++;
       if (chosenRow == dimension)
         break;
     }
      
      int tempNum = twin.tiles[chosenRow][0];
      twin.tiles[chosenRow][0] = twin.tiles[chosenRow][1];
      twin.tiles[chosenRow][1] = tempNum;
      return twin;
    }
      
    public boolean equals(Object y) {
      // does this board equal y?
      if (y == this) return true;
      if (y == null) return false;
      
      if (y.getClass() != this.getClass())
          return false;
      
      Board that = (Board)y;
      if (this.dimension() != that.dimension())
          return false;
      for (int i = 0; i < dimension; i++)
        for (int j = 0; j < dimension; j++) {
            if (this.tiles[i][j] != that.tiles[i][j])
              return false;
      }
      return true;
    }
    public Iterable<Board> neighbors() {
      // all neighboring boards
     Queue<Board> Q = new Queue<Board>();
      int blankRow = 0;
      int blankCol = 0;
   
      
      for (int i = 0; i < dimension; i++)
        for (int j = 0; j < dimension; j++) {
            if (tiles[i][j] == 0) {
               blankRow = i;
               blankCol = j;
            }
         }
        
        int[][] neighborTiles;
      
        neighborTiles = new int[dimension][dimension];
        for (int i = 0; i < dimension; i++)
          for (int j = 0; j < dimension; j++)
              neighborTiles[i][j] = tiles[i][j];
        
        if (blankRow != (dimension - 1)) {
          Board neighbor = new Board(neighborTiles);
          neighbor.tiles[blankRow][blankCol] = 
            neighbor.tiles[blankRow + 1][blankCol];
          neighbor.tiles[blankRow + 1][blankCol] = 0;
          Q.enqueue(neighbor);
        }
        
        if (blankCol != (dimension - 1)) {
          Board neighbor = new Board(neighborTiles);
          neighbor.tiles[blankRow][blankCol] = 
            neighbor.tiles[blankRow][blankCol + 1];
          neighbor.tiles[blankRow][blankCol + 1] = 0;
          Q.enqueue(neighbor);
        }
        
        if (blankRow != 0) {
          Board neighbor = new Board(neighborTiles);
          neighbor.tiles[blankRow][blankCol] =
            neighbor.tiles[blankRow - 1][blankCol];
          neighbor.tiles[blankRow - 1][blankCol] = 0;
          Q.enqueue(neighbor);
        }
        
        if (blankCol != 0) {
          Board neighbor = new Board(neighborTiles);
          neighbor.tiles[blankRow][blankCol] =
            neighbor.tiles[blankRow][blankCol - 1];
          neighbor.tiles[blankRow][blankCol - 1] = 0;
          Q.enqueue(neighbor);
        }
        return Q;
    }
        
    public String toString() {
      // string representation of the board (in the output format specified below)
      StringBuilder s = new StringBuilder();
      s.append(dimension + "\n");
      for (int i = 0; i < dimension; i++) {
        for (int j = 0; j < dimension; j++) {
            s.append(String.format("%2d ", tiles[i][j]));
        }
        s.append("\n");
      }
      return s.toString();
    }
}
 