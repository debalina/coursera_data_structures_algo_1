/*----------------------------------------------------------------
 *  Author:        Debalina Ghosh
 *  Written:       3/16/2013
 *  Last updated:  3/16/2013
 *
 * 
 *  This implements the A* algorithm for solving the 8-puzzle
 *  problem using the Board API and MinPQ class in algs4.jar.
 *  We use the Manhattan priority function that is the Manhattan 
 *  distances plus the number of moves from the initial search
 *  node. We use a twin board to find out whether the puzzle is
 *  solveable or not. If the twin reaches a solution, then the
 *  initial board is unsolvable. We use a private inner class Node
 *  that maintains a link to the parent search Node. At each iteration,
 *  we dequeue the node with the minimum priority and then enqueue all
 *  its neighbors in the priority queue. We continue until we reach a 
 *  goal board and then trace the parent pointers back to see whether 
 *  the goal was reached from the initial board or the twin board.
 *  
 *
 *----------------------------------------------------------------*/
import java.util.Comparator;

public class Solver {
    private Node searchNode;
    private Board initial;
    private Board twin;
    
    //definition of inner class Node
    private class Node{
        public final Comparator<Node> PRIORITY = new PriorityOrder();
        private Board board;
        private Node parent;
        private int moves;
         //priority is manhattan or hamming function plus # of moves
        // we use manhattan function here
        private int priority;
       
        private Node (Board b, Node p, int moves) {
            this.board = b;
            this.parent = p;
            //this.root = r;
            this.priority = b.manhattan() + moves;
            this.moves = moves;
        }
        
    
        private class PriorityOrder implements Comparator<Node> {
    
          //compare two nodes based on their priority
            public int compare(Node n1, Node n2) {
                if (n1.priority == n2.priority) 
                    return 0;
                else if (n1.priority < n2.priority)
                    return -1;
        
                return 1;
            }
        }
    }
    
    
    public Solver(Board initial) {
      // find a solution to the initial board (using the A* algorithm)
      this.initial = initial;
      this.twin = initial.twin();
      int m = 0;
      
      Node initialNode = new Node(initial, null, m);
      Node twinNode = new Node(twin, null, m);
      MinPQ<Node> priorityQ = new MinPQ<Node>(initialNode.PRIORITY);
     
      priorityQ.insert(initialNode);
      priorityQ.insert(twinNode);
      searchNode = priorityQ.delMin();
      
      while (!searchNode.board.isGoal()) {
          Iterable<Board> neighbors = searchNode.board.neighbors();
          m = ++searchNode.moves;
          for (Board b:neighbors) {
             // one of the neighbors will be the previous search node
            // do not insert that into PQ.
              
            if (searchNode.parent != null) {
                if (!b.equals(searchNode.parent.board)) {
                    Node newNode =new Node(b, searchNode, m);
                    priorityQ.insert(newNode);
                }
            } else {
                Node newNode =new Node(b, searchNode, m);
                priorityQ.insert(newNode);
            }
          }
          searchNode = priorityQ.delMin();
      }
   } 
      
      
    public boolean isSolvable() {
        // is the initial board solvable?
      if (solution() == null) return false;
      for (Board b:solution()) {
          if (b.equals(initial)) return true;
          // if there is a solution to twin, then there is no solution
          // to initial search node
          //if (b.equals(twin)) return false;
      }
      return false;
    }
    
    public int moves() {
      // min number of moves to solve initial board; -1 if no solution
         if (isSolvable())
             return searchNode.moves;
         else 
             return -1;
         
    }
    
    public Iterable<Board> solution()   {
        // sequence of boards in a shortest solution; null if no solution
        Stack<Board> stack = new Stack<Board>();
        int moves = 0;
        
        Node currentNode = searchNode;
    
        while ((currentNode != null) && 
               (!initial.equals(currentNode.board))
                 && (!twin.equals(currentNode.board))) {
            stack.push(currentNode.board);
            moves++;
            currentNode = currentNode.parent;
        }
        if (currentNode != null) {
            stack.push(currentNode.board);
        }
        if (twin.equals(currentNode.board))
            return null;
        return stack;
      }
    
    public static void main(String[] args)  {
      // create initial board from file
        In in = new In(args[0]);
        int N = in.readInt();
        int[][] blocks = new int[N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);


        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable()) 
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
         } 
      }
}